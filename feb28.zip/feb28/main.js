var summation = function (num) {
  let counter = 0
  for(i=0; i<=num;i++){
  counter += i;
  }
  return counter
}





console.log('sample answer for Feb 28th, 2020 is: ' + ' ' +summation(4));
